Put your own emoji/sticker images here (PNG, WEBP, GIF or JPG).
They show up in the "Custom" tab (last tab) of the SpeedKey emoji panel.
Use square images, ~256x256 px works best. File name = any name.
After adding files, rebuild the app (push to GitHub).
